package ar.edu.unicen.ccm;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IFile;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.AbstractTypeDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.DoStatement;
import org.eclipse.jdt.core.dom.EnhancedForStatement;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.ForStatement;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.SwitchStatement;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.WhileStatement;
import org.jgraph.graph.DefaultEdge;
import org.jgrapht.DirectedGraph;
import org.jgrapht.graph.DefaultDirectedGraph;

import ar.edu.unicen.ccm.bcs.MethodNode;
import ar.edu.unicen.ccm.bcs.MethodSignature;

/**
 * Crear tres archivos csv:  Uno para metodos,  otro para clases completas y el 
 * ultimo para jerarquias y el sistema total
 * @author pablo
 *
 */
public class Metrics {
	
	public static void analyzeJavaProject(IJavaProject project) {

		try {
			IPackageFragment[] packages = project.getPackageFragments();
			Collection<IPackageFragment> sourcePackages = new LinkedList<IPackageFragment>();
			Collection<TypeDeclaration> types = new LinkedList<TypeDeclaration>();
			
			for (IPackageFragment pk : packages) {
				if (pk.getKind() == IPackageFragmentRoot.K_SOURCE) 
					sourcePackages.add(pk);
			}
			//find all declared types (including nested ones)
			for (IPackageFragment pk : sourcePackages) {
				for (ICompilationUnit unit : pk.getCompilationUnits()) {
					ASTParser parser = ASTParser.newParser(AST.JLS3); 
					parser.setKind(ASTParser.K_COMPILATION_UNIT);
					parser.setSource(unit); // set source
					parser.setResolveBindings(true); // we need bindings later on
					CompilationUnit cu =  (CompilationUnit)parser.createAST(null /* IProgressMonitor */); // parse
					for (AbstractTypeDeclaration t : (List<AbstractTypeDeclaration>)cu.types()) {
						System.out.println("Adding type " + t);
						if (t.getNodeType() == t.TYPE_DECLARATION) {
							TypeDeclaration td = (TypeDeclaration)t;
							types.add((TypeDeclaration)t);
							for (TypeDeclaration childType : td.getTypes())
								types.add(childType);
						}
					}
				}
			}
			DirectedGraph<MethodNode, DefaultEdge> methodGraph = new DefaultDirectedGraph<MethodNode, DefaultEdge>(DefaultEdge.class);
			
			Map<String, MethodNode> map = new HashMap<String, MethodNode>();
			
			DirectedGraph<String, DefaultEdge> hierarchy = new DefaultDirectedGraph<String, DefaultEdge>(DefaultEdge.class);
			
			Map<String, Integer> classWeight = new HashMap<String, Integer>();
			
			// create the hierarchy vertex
			for (TypeDeclaration t : types) {
				if (!t.isInterface()) {//TODO: agregar las interfaces
					System.out.println("Adding type hierarchy vertex " + t.resolveBinding().getQualifiedName());
					hierarchy.addVertex(t.resolveBinding().getQualifiedName());
				}
			}

			// create the links TODO: add interfaces
			// TODO: interfaces not in this project ALSO must be addedd.. to find references
			for (TypeDeclaration t : types) {
				ITypeBinding tb = t.resolveBinding();
				System.out.println(tb.getQualifiedName() + "=>" + tb.getSuperclass().getQualifiedName());
				if (hierarchy.containsVertex(tb.getSuperclass().getQualifiedName())) {
					System.out.println("Adding superclass edge");
					hierarchy.addEdge(tb.getSuperclass().getQualifiedName(), tb.getQualifiedName());
				}
			}
			
			// populate the method graph with all its vertex
			for (TypeDeclaration t : types) {
				MethodDeclaration[] methods = t.getMethods();
				for (MethodDeclaration md : methods) {
					
					MethodNode mn = new MethodNode(md, methodGraph);
					System.out.println("Adding vertex " + mn);
					methodGraph.addVertex(mn);
					map.put(mn.getSignature(), mn);
				}
				
			}
			
			for(MethodNode node : methodGraph.vertexSet()) 
				node.calculateDependencies();
				
			
			//we had the entire dependency graph populated,  now we can
			//calculate the cognitive weight,  without entering into loops
			for(MethodNode node : methodGraph.vertexSet()) {
				int cost = node.getCost(map);
				System.out.println(node.getSignature() );
				System.out.println(node.getExpr());
				System.out.println("=>" + cost);
				System.out.println("----------");
			}
			
			
			List<String> root = new LinkedList<String>();
			for(String t : hierarchy.vertexSet()) {
				System.out.println(t + "in: " + hierarchy.inDegreeOf(t));
				System.out.println(t + "out: " + hierarchy.outDegreeOf(t));
				if (hierarchy.inDegreeOf(t) == 0) {  
					//TODO: que no sea interfaz..
					//it is not subclass of any class in this project
					root.add(t);
				}
			}
			
			int totalCost = 0;
			
		
			
			
			
			StringBuilder b = new StringBuilder("\"Method\", \"Weight\", \"Weight Expression\"\r\n");
			for (MethodNode m : methodGraph.vertexSet()) {
				b.append("\"").append(m.getSignature()).append("\", ");
				b.append("\"").append(m.getCost(map)).append("\", ");
				b.append("\"").append(m.getExpr()).append("\" \r\n");
			}
				 
			
			IFile f = project.getProject().getFile("mc.csv");
			if (f.exists())
				f.delete(true, null);
			f.create(new ByteArrayInputStream(b.toString().getBytes()), true, null);
			
			

			b = new StringBuilder("\"Class\", \"# methods\", \"# attributes\", \"Average Method Complexity\", \"Weight\"\r\n");
			for(TypeDeclaration t : types) {
				int cost = 0;
				for (MethodDeclaration m : t.getMethods()) {
					String ms  = MethodSignature.from(m.resolveBinding());
					cost +=  map.get(ms).getCost(map);
				}
				float averageMethodComplexity = 0;
				if (t.getMethods().length != 0)
					averageMethodComplexity = cost / t.getMethods().length;
				
				cost += t.getFields().length;
				
				
				System.out.println(t.resolveBinding().getQualifiedName()  + ":" + cost);
				b.append("\"").append(t.resolveBinding().getQualifiedName()).append("\", ");
				b.append("\"").append(t.getMethods().length).append("\", ");
				b.append("\"").append(t.getFields().length).append("\", ");
				b.append("\"").append(averageMethodComplexity).append("\", ");
				b.append("\"").append(cost).append("\"\r\n");
				classWeight.put(t.resolveBinding().getQualifiedName(), cost);
			}
			f = project.getProject().getFile("wcc.csv");
			if (f.exists())
				f.delete(true, null);
			f.create(new ByteArrayInputStream(b.toString().getBytes()), true, null);
			
			 
			b = new StringBuilder("\"Hierarchy\", \"Weight\"\r\n");
			for (String t : root) {
				int hcost = hierarchyCostOf(classWeight, hierarchy, t);
				totalCost += hcost; 
				b.append("\"").append(t).append("\",");
				b.append("\"").append(hcost).append("\"\r\n");
			}
			b.append("\"").append("TOTAL").append("\",");
			b.append("\"").append(totalCost).append("\"");

			f = project.getProject().getFile("code_complexity.csv");
			if (f.exists())
				f.delete(true, null);
			f.create(new ByteArrayInputStream(b.toString().getBytes()), true, null);
			


			
			} catch (JavaModelException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	private static int hierarchyCostOf(Map<String, Integer> classWeight, DirectedGraph<String, DefaultEdge> hierarchy, String t) {
		System.out.println("hierarchyCostOf " + t);
		int selfCost = classWeight.get(t);
 		Set<DefaultEdge> subclasses = hierarchy.outgoingEdgesOf(t);
		if (subclasses.isEmpty())
			return selfCost;
		else {
			int childCost = 0;
			for (DefaultEdge e : subclasses) {
				String child = hierarchy.getEdgeTarget(e);
				childCost += hierarchyCostOf(classWeight, hierarchy, child);
			}
			return selfCost * childCost;
		}
	}

}
