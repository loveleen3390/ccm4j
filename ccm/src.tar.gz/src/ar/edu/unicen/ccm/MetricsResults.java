package ar.edu.unicen.ccm;

import java.util.Collection;

public class MetricsResults {

	public Collection<String> getClasses() {
		return null;
	}
	public Collection<String> getMethods(String clazz) {
		return null;
	}
	
	
	
}
