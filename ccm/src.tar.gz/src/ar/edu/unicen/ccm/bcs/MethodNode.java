package ar.edu.unicen.ccm.bcs;

import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.AnnotationTypeDeclaration;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.Modifier;
import org.jgraph.graph.DefaultEdge;
import org.jgrapht.DirectedGraph;

import ar.edu.unicen.ccm.WeightFactors;

public class MethodNode {
	//this is used as the key to lookup methods in the graph
	String methodSignature;
	
	DirectedGraph<MethodNode, DefaultEdge> graph;
	MethodDeclaration md;
	
	int cost; //complete cost
	int flatCost; //"flat" cost: don't take recursion into account
	
	String expr;
	
	
	public MethodNode(MethodDeclaration md, DirectedGraph<MethodNode, DefaultEdge> g) {
		this.methodSignature = MethodSignature.from(md.resolveBinding());
		this.md = md;
		this.graph = g;
		this.cost = -1; 
		this.flatCost = -1;
	}

	//this will only be used for lookup
	public MethodNode(IMethodBinding mb) {
		this.methodSignature = MethodSignature.from(mb);
	}
	
	public String getSignature() {
		return methodSignature;
	}
	public void addCallTo(IMethodBinding mb) {
		MethodNode called = new MethodNode(mb);
		System.out.println("Evaluating call to " + called);
		if (graph.containsVertex(called)) {
			//Otherwise it is a library api
			System.out.println(this + "->" + called);
			this.graph.addEdge(this, called);
		}
	}
	
	public void calculateDependencies() {
		DependencyVisitor v = new DependencyVisitor(this);
		this.md.getBody().accept(v);
	}
	
	public String getExpr() {
		return this.expr;
	}
	public int getCost(Map<String, MethodNode> map) {
		if (this.cost == -1) {
			IMethodBinding mb = md.resolveBinding();
			if (mb.getDeclaringClass().isInterface() ||
					Modifier.isAbstract(md.getModifiers()))
				this.cost = 1; // TODO:  average over all implementations..
			else {
					WCCVisitor visitor = new WCCVisitor(this, this.graph, map, false, WeightFactors.sequenceWeight());
					this.md.getBody().accept(visitor);
					this.cost = visitor.cost;
					this.expr = visitor.getExpr();
			}
		}
		return this.cost;
	}
	
	
	
	public int getFlatCost(Map<String, MethodNode> map) {
		if (this.flatCost == -1) {
			IMethodBinding mb = md.resolveBinding();
			if (mb.getDeclaringClass().isInterface() ||
					Modifier.isAbstract(md.getModifiers()))
				this.flatCost = 1; // TODO:  average over all implementations..
			else {
					WCCVisitor visitor = new WCCVisitor(this, this.graph, map, true, 1);
					this.md.getBody().accept(visitor);
					this.flatCost = visitor.cost;
			}
		}
		return this.flatCost;
	}
	
	public String toString() {
		return this.methodSignature;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof MethodNode ) {
			MethodNode other = (MethodNode) obj;
			return this.methodSignature.equals(other.methodSignature);
		} 
		return false;
	}
	
	@Override
	public int hashCode() {
		return this.methodSignature.hashCode();
	}
	
	
	private class DependencyVisitor extends ASTVisitor {
		MethodNode node;
		public DependencyVisitor(MethodNode node) {
			this.node = node;
		}
		@Override
		public boolean visit(MethodInvocation mi) {
			node.addCallTo(mi.resolveMethodBinding());
			return super.visit(mi);
		}
	}
	
	
}
