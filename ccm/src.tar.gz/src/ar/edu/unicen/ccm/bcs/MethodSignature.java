package ar.edu.unicen.ccm.bcs;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;


public class MethodSignature {
	
	public static String from(IMethodBinding mb) {
		String clazz = mb.getDeclaringClass().getQualifiedName();
		String name = mb.getName();
		List<String> params = new LinkedList<String>();
		for (ITypeBinding p : mb.getParameterTypes())
			params.add(p.getQualifiedName());
		return calculateId(clazz, name, params);
	}
	
	
	private static String calculateId(String clazz, String name, List<String> arguments) {
		StringBuilder b = new StringBuilder(clazz);
		b.append(".").append(name).append("(");
		b.append(join(arguments, ","));
		return b.append(")").toString();
	}
	
	private static String join(Collection<String> s, String delimiter) {
	     StringBuilder builder = new StringBuilder();
	     Iterator<String> iter = s.iterator();
	     while (iter.hasNext()) {
	         builder.append(iter.next());
	         if (!iter.hasNext()) {
	           break;                  
	         }
	         builder.append(delimiter);
	     }
	     return builder.toString();
	 }

	
}
